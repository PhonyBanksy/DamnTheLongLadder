#!/usr/bin/env python3
"""
oil_control.py - tiny web control panel for the oil_live systemd service.

Lets you start / stop / restart / view-logs from a browser instead of
SSH. Runs on port 8001 so it doesn't clash with the dashboard on 8000.

Setup (one-time):
    sudo cp oil_control.service /etc/systemd/system/
    sudo cp oil_control_sudoers /etc/sudoers.d/oil_control
    sudo systemctl daemon-reload
    sudo systemctl enable --now oil_control

Then open:  http://<pi-ip>:8001
"""

import subprocess
from flask import Flask, jsonify, request

SERVICE = "oil_live"           # the systemd unit we control
PORT = 8001
DASHBOARD_PORT = 8000

app = Flask(__name__)


def run(*args):
    """Run a command, return (ok, combined_output)."""
    try:
        p = subprocess.run(args, capture_output=True, text=True, timeout=15)
        out = (p.stdout + p.stderr).strip()
        return p.returncode == 0, out
    except Exception as exc:
        return False, str(exc)


def is_active() -> bool:
    ok, out = run("systemctl", "is-active", SERVICE)
    return out.strip() == "active"


@app.route("/api/status")
def status():
    _, full = run("systemctl", "status", SERVICE, "--no-pager", "-n", "0")
    return jsonify(active=is_active(), detail=full)


@app.route("/api/logs")
def logs():
    # last 60 lines from journald, newest at the bottom
    _, out = run("journalctl", "-u", SERVICE, "-n", "60", "--no-pager")
    return jsonify(text=out or "(no logs yet)")


@app.route("/api/action", methods=["POST"])
def action():
    cmd = request.json.get("cmd") if request.is_json else None
    if cmd not in {"start", "stop", "restart"}:
        return jsonify(ok=False, msg="unknown command"), 400
    ok, out = run("sudo", "-n", "systemctl", cmd, SERVICE)
    return jsonify(ok=ok, msg=out or f"{cmd} sent", active=is_active())


@app.route("/")
def index():
    return PAGE.replace("__DASH_PORT__", str(DASHBOARD_PORT))


PAGE = """<!doctype html>
<html><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Oil dashboard - control</title>
<style>
 body{font-family:system-ui,sans-serif;background:#111;color:#eee;margin:0;padding:16px}
 .card{background:#1b1b1b;border-radius:12px;padding:18px;margin:0 auto 16px;max-width:720px}
 h1{margin:0 0 6px;font-size:1.3rem}
 .row{display:flex;gap:10px;flex-wrap:wrap;margin-top:14px}
 button{flex:1;min-width:120px;padding:12px 14px;border:0;border-radius:10px;
        font-size:1rem;font-weight:600;cursor:pointer;color:#fff}
 .start{background:#2e7d32}.stop{background:#c62828}.restart{background:#1565c0}
 .open{background:#444}
 button:disabled{opacity:.5;cursor:wait}
 .dot{display:inline-block;width:10px;height:10px;border-radius:50%;margin-right:8px;vertical-align:middle}
 .on{background:#66bb6a}.off{background:#ef5350}.unk{background:#888}
 pre{background:#000;color:#9c9;padding:12px;border-radius:8px;max-height:340px;
     overflow:auto;font-size:.8rem;white-space:pre-wrap;word-break:break-word}
 small{color:#888}
</style></head><body>

<div class="card">
  <h1>Oil dashboard control</h1>
  <div id="state"><span class="dot unk"></span><small>checking...</small></div>
  <div class="row">
    <button class="start"   onclick="act('start')">Start</button>
    <button class="stop"    onclick="act('stop')">Stop</button>
    <button class="restart" onclick="act('restart')">Restart</button>
    <button class="open"    onclick="openDash()">Open dashboard</button>
  </div>
  <p><small>The dashboard itself lives on port __DASH_PORT__.
     This panel only manages whether it's running.</small></p>
</div>

<div class="card">
  <h1>Recent logs</h1>
  <small>auto-refreshes every 5s</small>
  <pre id="logs">loading...</pre>
</div>

<script>
async function refresh(){
 try{
  const s = await (await fetch('/api/status')).json();
  const dot = s.active ? 'on' : 'off';
  const txt = s.active ? 'running' : 'stopped';
  document.getElementById('state').innerHTML =
    '<span class="dot '+dot+'"></span><b>'+txt+'</b>';
  const l = await (await fetch('/api/logs')).json();
  const pre = document.getElementById('logs');
  const atBottom = pre.scrollHeight - pre.scrollTop - pre.clientHeight < 40;
  pre.textContent = l.text;
  if(atBottom) pre.scrollTop = pre.scrollHeight;
 }catch(e){ console.error(e); }
}
async function act(cmd){
 const btns = document.querySelectorAll('button');
 btns.forEach(b => b.disabled = true);
 try{
  await fetch('/api/action', {method:'POST',
    headers:{'Content-Type':'application/json'},
    body: JSON.stringify({cmd})});
  await new Promise(r => setTimeout(r, 800));
  await refresh();
 } finally {
  btns.forEach(b => b.disabled = false);
 }
}
function openDash(){
 const url = location.protocol + '//' + location.hostname + ':__DASH_PORT__';
 window.open(url, '_blank');
}
refresh(); setInterval(refresh, 5000);
</script>
</body></html>"""


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=PORT)
